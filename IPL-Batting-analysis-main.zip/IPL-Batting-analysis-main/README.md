# IPL-Batting-analysis

In this project I ve bulit a predictive model using machine learning algorithm such as  linear regression and etc



LIBRARIES USED : 

Data cleaning  and preprocessing : pandas , numpy

Data visualization : matplotlib , seaborn 

Machine learning alghorithms : Sklearn 

dataset used : https://www.kaggle.com/ramjidoolla/ipl-data-set?select=most_runs_average_strikerate.csv

columns(parameters) : batsman name , total runs ,number of balls faced , outs, average , strike rate

In this project I've built a predictive model which will predict the number of runs the batsman will score in upcoming seasons by training the data which a batsman scored in previous seasons.

